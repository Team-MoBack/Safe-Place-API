package com.jwtDemo.jwtDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
